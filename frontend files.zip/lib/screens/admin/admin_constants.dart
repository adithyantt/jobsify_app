class AdminConstants {
  static const String appTitle = "Jobsify Admin";

  static const String dashboard = "Dashboard";
  static const String jobVerification = "Job Verification";
  static const String providerVerification = "Provider Verification";
  static const String reports = "Reports";
  static const String users = "Users";
  static const String apiKeyManagement = "API Key Management";
}
