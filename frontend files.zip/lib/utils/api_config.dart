class ApiConfig {
  static const String baseUrl = "http://10.13.1.105:8001";
}
