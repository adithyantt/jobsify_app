class ApiConstants {
  static const List<String> adminEmails = [
    'admin@jobsify.com',
    'jobsify.admin@gmail.com',
    'superadmin@jobsify.com',
  ];
}
